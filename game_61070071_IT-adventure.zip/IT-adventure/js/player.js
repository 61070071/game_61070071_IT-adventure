var player = {
    player1: {
        step: 0,
        life: 3,
        status: 1,
        character: 0,
        move: 1
    },
    player2: {
        step: 0,
        life: 3,
        status: 1,
        character: 0,
        move: 1
    },
    player3: {
        step: 0,
        life: 3,
        status: 0,
        character: 0,
        move: 1
    },
    player4: {
        step: 0,
        life: 3,
        status: 0,
        character: 0,
        move: 1
    },
};